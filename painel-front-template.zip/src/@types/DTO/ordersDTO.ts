
export interface getAllOrdersDTO {
	user: {
		name: string,
		phone: string,
		email: string,
		doc: string,
		isOrganization: boolean
	},
	address: {
		street: string,
		state: string,
		cep: string,
		city: string,
	},
	_id: string,
	ecma: string,
	idXDB: string,
	status: string,
	csr: string,
	dataEmission: string,
	dateUntil: string,
	domain: string,
	idCert?: getCertDTO
	totalPrice: string,
	idUser?: getUserDTO,
	paymentMethod: string,
}

export interface getUserDTO {
	idUser: {
		address: {
			street: string,
			state: string,
			city: string,
			cep: string,
		},
		_id: string,
		name: string,
		password: string,
		email: string,
		phone: string,
		doc: string,
		isOrganization: boolean
		paymentMethod: string,
		approved: boolean,
		type: string,
		file: [
			string,
		],
		createdAt: string,
		updatedAt: string,
		__v: number,
		tokenOTP?: string,
	},
}
export interface getCertDTO {

	 _id : string,
	 idProduto :  number
	 nome : string,
	 tipo :string,
	 validades : [
		{
			 '1 ano' : string,
		},
		{
			 '2 ano' : string,
		},
		{
			 '3 ano' : string,
		}
	]

}

