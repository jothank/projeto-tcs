export interface ProductsDTO {
    _id: number,
    nomeCert: string,
    regData: string,
    untilData:  string,
    regNextData: string,
    circleByling?: string,
    price: string,
    src?: string,
    quantity: string,
  }

  export interface infoClientDTO {
    _id?: number,
    cpf: string,
    firstName: string,
    lastName: string,
    email: string,
    officeRole: string,
  }