import { createContext, useCallback, useContext, useState } from 'react';
import { ProductsDTO, infoClientDTO } from '../@types/DTO/productsDTO';

export interface EmissonContent {
  addProducts?: (content: ProductsDTO[]) => void;
  addCsr?: (content: any) => void;
  csr?: string;
  addCsrError?: (content: boolean) => void;
  addCsrLoading?: (content: boolean) => void;
  csrError?: boolean;
  csrLoading?: boolean;

  addInfoClient?: (content: infoClientDTO) => void;
  addInfoClientError?: (content: boolean) => void;
  addInfoClientLoading?: (content: boolean) => void ;
  infoClient?: infoClientDTO;
  infoClientError?: boolean;
  infoClientLoading?: boolean;
}

const NewEmissionContext = createContext<EmissonContent>({} as EmissonContent);

const NewEmissionProvider = ({ children }: any) => {
  const [producsSelected, setProductsSelected] = useState<ProductsDTO[]>([
    {
      _id: 0,
      nomeCert: '',
      regData: '',
      untilData: '',
      regNextData: '',
      circleByling: '',
      price: '',
      quantity: '',
    },
  ]);

  const [infoClient, setInfoClient] = useState<infoClientDTO>({
      _id: 0,
      cpf: '',
      firstName: '',
      lastName: '',
      email: '',
      officeRole: '',
  });
  const [infoClientError, setInfoClientError] = useState<boolean>(false);
  const [infoClientLoading, setInfoClientLoading] = useState<boolean>(false);

  const [csr, setCsr] = useState('');
  const [csrError, setCsrError] = useState(true);
  const [csrLoading, setCsrLoading] = useState(false);

  console.log('infoClient',infoClient)
  const addInfoClient = useCallback((content: infoClientDTO) => {

    console.log('infoClient content',content)
    setInfoClient(content);
  }, []);

  const addInfoClientError = useCallback((content: boolean) => {
    setInfoClientError(content);
  }, []);

  const addInfoClientLoading = useCallback((content: boolean) => {
    setInfoClientLoading(content);
  }, []);

  const addProducts = useCallback((content: ProductsDTO[]) => {
    setProductsSelected(content);
  }, []);

  const addCsr = useCallback((content: any) => {
    setCsr(content);
  }, []);

  const addCsrLoading = useCallback((content: boolean) => {
    setCsrLoading(content);
  }, []);

  const addCsrError = useCallback((content: boolean) => {
    setCsrError(content);
  }, []);

  return (
    <NewEmissionContext.Provider
      value={{
        addProducts,
        addCsr,
        csr,
        addCsrError,
        addCsrLoading,
        csrError,
        csrLoading,
        addInfoClient,
        addInfoClientError,
        addInfoClientLoading,
        infoClient,
        infoClientError,
        infoClientLoading,
      }}
    >
      {children}
    </NewEmissionContext.Provider>
  );
};

function useNewEmissionContext() {
  return useContext(NewEmissionContext);
}

export { NewEmissionProvider, useNewEmissionContext };
