export { default } from './CompactLayout';
