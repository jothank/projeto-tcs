import FullCalendar from '@fullcalendar/react'; // => request placed at the top
import { DateSelectArg, EventClickArg, EventDropArg, EventInput } from '@fullcalendar/core';
import listPlugin from '@fullcalendar/list';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import timelinePlugin from '@fullcalendar/timeline';
import interactionPlugin, { EventResizeDoneArg } from '@fullcalendar/interaction';
import { useState, useRef, useEffect, useCallback, SetStateAction } from 'react';
import { Helmet } from 'react-helmet-async';
// @mui
import { Card, Container, DialogTitle, Dialog, Paper, Typography, Divider, Box, Button } from '@mui/material';
// redux
import { useDispatch, useSelector } from '../redux/store';
import { getEvents, createEvent, updateEvent, deleteEvent } from '../redux/slices/calendar';

// utils
import { fDate, fDateTime, fParse, fTimestamp } from '../utils/formatTime';
// hooks
import useResponsive from '../hooks/useResponsive';
// @types
import { ICalendarEvent, ICalendarViewValue } from '../@types/calendar';
// components
import { useSnackbar } from '../components/snackbar';
import { useSettingsContext } from '../components/settings';
import { useDateRangePicker } from '../components/date-range-picker';
// sections
import {
  StyledCalendar,
  CalendarToolbar,
  CalendarFilterDrawer,
} from '../components/calendar';

import ptLocale from '@fullcalendar/core/locales/pt-br';
import { listAllOrdersAPI } from '../services/orders.services';
import { getAllOrdersDTO } from '../@types/DTO/ordersDTO';
import { differenceInDays, formatISO } from 'date-fns';
import { useNavigate } from 'react-router';


// ----------------------------------------------------------------------

const COLOR_OPTIONS = [
  '#00AB55', // theme.palette.primary.main,
  '#1890FF', // theme.palette.info.main,
  '#54D62C', // theme.palette.success.main,
  '#FFC107', // theme.palette.warning.main,
  '#FF4842', // theme.palette.error.main
  '#04297A', // theme.palette.info.darker
  '#7A0C2E', // theme.palette.error.darker
];

// ----------------------------------------------------------------------

export default function Calendar() {
  const { enqueueSnackbar } = useSnackbar();

  const { themeStretch } = useSettingsContext();
  const navigateTo = useNavigate();
  const dispatch = useDispatch();

  const isDesktop = useResponsive('up', 'sm');

  const calendarRef = useRef<FullCalendar>(null);

  const events = useGetEvents();

  const [openForm, setOpenForm] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [selectedRange, setSelectedRange] = useState<{
    start: Date;
    end: Date;
  } | null>(null);


  const picker = useDateRangePicker(null, null);
  const [date, setDate] = useState(new Date());
  const [openFilter, setOpenFilter] = useState(false);
  const [filterEventColor, setFilterEventColor] = useState<string[]>([]);
  const [view, setView] = useState<ICalendarViewValue>(isDesktop ? 'dayGridMonth' : 'listWeek');
  const [dataCalendar, setDataCalendar] = useState<any>([]);
  const [selectedCertEvent, setSelectedCertEvent] = useState<any>([]);


  // useEffect(() => {
  //   const calendarEl = calendarRef.current;
  //   if (calendarEl) {
  //     const calendarApi = calendarEl.getApi();

  //     const newView = isDesktop ? 'dayGridMonth' : 'listWeek';
  //     calendarApi.changeView(newView);
  //     setView(newView);
  //   }
  // }, [isDesktop]);

  useEffect(() => {
    getAllOrders()
  }, [])

  const getAllOrders = () => {

    listAllOrdersAPI().then(res => {
      const dataSet = res.data.map((item: getAllOrdersDTO) => {
      
        return {
          allDay: false,
          color: "#00AB55",
          description: item.idCert?.nome,
          end: fParse(item.dataEmission),
          endDate: fParse(item.dateUntil),
          id: item.idXDB,
          start: fParse(item.dataEmission),
          textColor: "#00AB55",
          title: item.idCert?.nome,
          domain: item.domain,
          status: item.status,
          emissor: item.user.name
        }
      })

      console.log("dataTotal", dataSet)

      setDataCalendar(dataSet);

    }).catch(err => {
      console.log("error", err)
    })
  }

  const handleOpenModal = () => {
    setOpenForm(true);
  };

  const handleCloseModal = () => {
    setOpenForm(false);
    setSelectedRange(null);
    setSelectedEventId(null);
  };

  const handleClickToday = () => {
    const calendarEl = calendarRef.current;
    if (calendarEl) {
      const calendarApi = calendarEl.getApi();

      calendarApi.today();
      setDate(calendarApi.getDate());
    }
  };

  const handleChangeView = (newView: ICalendarViewValue) => {
    const calendarEl = calendarRef.current;
    if (calendarEl) {
      const calendarApi = calendarEl.getApi();

      calendarApi.changeView(newView);
      setView(newView);
    }
  };

  const handleClickDatePrev = () => {
    const calendarEl = calendarRef.current;
    if (calendarEl) {
      const calendarApi = calendarEl.getApi();

      calendarApi.prev();
      setDate(calendarApi.getDate());
    }
  };

  const handleClickDateNext = () => {
    const calendarEl = calendarRef.current;
    if (calendarEl) {
      const calendarApi = calendarEl.getApi();

      calendarApi.next();
      setDate(calendarApi.getDate());
    }
  };

  const handleSelectRange = (arg: DateSelectArg) => {
    const calendarEl = calendarRef.current;
    if (calendarEl) {
      const calendarApi = calendarEl.getApi();

      calendarApi.unselect();
    }
    handleOpenModal();
    setSelectedRange({
      start: arg.start,
      end: arg.end,
    });
  };

  const handleSelectEvent = (arg: EventClickArg) => {
    const getCert = dataCalendar.find((item: any) => item.id === arg.event._def.publicId)
    setSelectedCertEvent(getCert);
    handleOpenModal();
    setSelectedEventId(arg.event.id);
  };

  // const handleResizeEvent = ({ event }: any) => {
  //   try {
  //     dispatch(
  //       updateEvent(event.id, {
  //         allDay: event.allDay,
  //         start: event.start,
  //         end: event.end,
  //       })
  //     );
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };



  const sendToCert = (idCert : number) => {
    navigateTo(`/home/certificados/gerenciar-certificados/${idCert}`);
  }

  const handleFilterEventColor = (eventColor: string) => {
    const checked = filterEventColor.includes(eventColor)
      ? filterEventColor.filter((value) => value !== eventColor)
      : [...filterEventColor, eventColor];

    setFilterEventColor(checked);
  };

  const handleResetFilter = () => {
    const { setStartDate, setEndDate } = picker;

    if (setStartDate && setEndDate) {
      setStartDate(null);
      setEndDate(null);
    }

    setFilterEventColor([]);
  };

  const dataFiltered = applyFilter({
    inputData: dataCalendar,
    filterEventColor,
    filterStartDate: picker.startDate,
    filterEndDate: picker.endDate,
    isError: !!picker.isError,
  });


  return (
    <>
      <Helmet>
        <title>Calendário de Certificados</title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'xl'}>
        <Paper elevation={3} style={{ padding: '2rem', marginTop: '2rem' }} >
          <Typography variant="h3" paragraph>
            Calendário
          </Typography>

          <StyledCalendar>
            <CalendarToolbar
              date={date}
              view={view}
              onNextDate={handleClickDateNext}
              onPrevDate={handleClickDatePrev}
              onToday={handleClickToday}
              onChangeView={handleChangeView}
              onOpenFilter={() => setOpenFilter(true)}
            />

            <FullCalendar
              locale={ptLocale}
              weekends
              editable
              rerenderDelay={10}
              allDayMaintainDuration
              eventResizableFromStart
              ref={calendarRef}
              initialDate={date}
              initialView={view}
              dayMaxEventRows={3}
              eventDisplay="block"
              events={dataFiltered}
              headerToolbar={false}
              initialEvents={dataFiltered}
              select={handleSelectRange}
              eventClick={handleSelectEvent}
              height={isDesktop ? 720 : 'auto'}
              plugins={[
                listPlugin,
                dayGridPlugin,
                timelinePlugin,
                timeGridPlugin,
                interactionPlugin,
              ]}
            />
          </StyledCalendar>
        </Paper>
      </Container>

      <Dialog fullWidth maxWidth="xs" open={openForm} onClose={handleCloseModal} >
        <DialogTitle>{selectedCertEvent.title}(#{selectedCertEvent.id})</DialogTitle>
        <Divider />
        <Box style={{ margin: '1.5rem' }}>
          <Typography variant="subtitle2" paragraph>
            <strong>Emissão:</strong><br />
            {fDateTime(selectedCertEvent.start, 'dd/MM/yyyy HH:mm')}
          </Typography>
          <Typography variant="subtitle2" paragraph>
            <strong>Vencimento:</strong><br />
            {fDateTime(selectedCertEvent.endDate, 'dd/MM/yyyy HH:mm')}
          </Typography>
          <Typography variant="subtitle2" paragraph>
            <strong>Dias para Vencer:</strong><br />
            <span style={{color:'#017835'}}>{differenceInDays(new Date(selectedCertEvent.endDate), new Date(selectedCertEvent.start))} dias</span>
          </Typography>
          <Typography variant="subtitle2" paragraph>
            <strong>Domínio:</strong><br />
            {selectedCertEvent.domain}
          </Typography>
          <Typography variant="subtitle2" paragraph>
            <strong>Emissor:</strong><br />
            {selectedCertEvent.emissor}
          </Typography>
          <Button
          style={{marginTop: '1rem', background:'#001d36', height: '50px'}}
          fullWidth
          onClick={() => sendToCert(selectedCertEvent.id)}
          variant='contained'
          color='primary'
        >
          Ver Certificado
        </Button>
        </Box>
       
      </Dialog>

      <CalendarFilterDrawer
        events={dataCalendar}
        picker={picker}
        openFilter={openFilter}
        onResetFilter={handleResetFilter}
        filterEventColor={filterEventColor}
        onCloseFilter={() => setOpenFilter(false)}
        onFilterEventColor={handleFilterEventColor}
        onSelectEvent={(eventId: SetStateAction<string | null>) => {
          if (eventId) {
            handleOpenModal();
            setSelectedEventId(eventId);
          }
        }}
      />
    </>
  );
}

// ----------------------------------------------------------------------

const useGetEvents = () => {
  const dispatch = useDispatch();

  const { events: data } = useSelector((state: { calendar: any; }) => state.calendar);

  const getAllEvents = useCallback(() => {
    dispatch(getEvents());
  }, [dispatch]);

  useEffect(() => {
    getAllEvents();
  }, [getAllEvents]);

  const events = data.map((event: { color: any; }) => ({
    ...event,
    textColor: event.color,
  }));

  return events;
};

// ----------------------------------------------------------------------

function applyFilter({
  inputData,
  filterEventColor,
  filterStartDate,
  filterEndDate,
  isError,
}: {
  inputData: EventInput[];
  filterEventColor: string[];
  filterStartDate: Date | null;
  filterEndDate: Date | null;
  isError: boolean;
}) {
  const stabilizedThis = inputData.map((el, index) => [el, index] as const);

  inputData = stabilizedThis.map((el) => el[0]);

  if (filterEventColor.length) {
    inputData = inputData.filter((event: EventInput) =>
      filterEventColor.includes(event.color as string)
    );
  }

  if (filterStartDate && filterEndDate && !isError) {
    inputData = inputData.filter(
      (event: EventInput) =>
        fTimestamp(event.start as Date) >= fTimestamp(filterStartDate) &&
        fTimestamp(event.end as Date) <= fTimestamp(filterEndDate)
    );
  }

  return inputData;
}
