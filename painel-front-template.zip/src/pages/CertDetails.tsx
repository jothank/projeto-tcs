import { Helmet } from 'react-helmet-async';
import { Container, Typography, Paper, Grid, Divider, Accordion, AccordionDetails, AccordionSummary } from '@mui/material';
import { useSettingsContext } from '../components/settings';
import { useParams } from 'react-router';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CheckIcon from '@mui/icons-material/CheckCircleRounded';
import ErrorIcon from '@mui/icons-material/Error';


export default function Calendar() {
  const { themeStretch } = useSettingsContext();
  const params = useParams();

  console.log(params);
  return (
    <>
      <Helmet>
        <title> Status Certificado </title>
      </Helmet>

      <Container maxWidth={themeStretch && false}>
        <Paper elevation={3} style={{ padding: '2rem', marginTop: '2rem' }} >
          <Typography mb={2} variant="h3" paragraph>
            Status do Certificado
          </Typography>
          <Divider />
          <Grid container spacing={1} justifyContent="space-between" mt={1}>
            <Grid item >
              <Typography variant="body1" style={{ color: '#8f8f8f' }}>
                Ordem Sectigo
              </Typography>
              <Typography variant="body1" style={{ fontSize: '1rem' }} paragraph>
                #{params.certId}
              </Typography>
            </Grid>
            <Grid item >
              <Typography variant="body1" style={{ color: '#8f8f8f' }}>
                ID X.Digital
              </Typography>
              <Typography variant="body1" style={{ fontSize: '1rem' }} paragraph>
                243949
              </Typography>
            </Grid>
            <Grid item >
              <Typography variant="body1" style={{ color: '#8f8f8f' }}>
                Tipo de Certificado
              </Typography>
              <Typography variant="body1" style={{ fontSize: '1rem' }} paragraph>
                Certificado Premium Wildcard OV
              </Typography>
            </Grid>
            <Grid item >
              <Typography variant="body1" style={{ color: '#8f8f8f' }}>
                Domínio
              </Typography>
              <Typography variant="body1" style={{ fontSize: '1rem' }} paragraph>
                hom-carteiradigital.estaleiro.serpro.gov.br
              </Typography>
            </Grid>
            <Grid item >
              <Typography variant="body1" style={{ color: '#8f8f8f' }}>
                Solicitante
              </Typography>
              <Typography variant="body1" style={{ fontSize: '1rem' }} paragraph>
                Wesley da Silva Sauro
              </Typography>
            </Grid>

            <Grid item xs={12} mb={1}>
              <Typography variant="h3" style={{ fontSize: '1.4rem' }}>
                Em andamento
              </Typography>
            </Grid>

            <Grid item xs={12} mb={4}>
              <Accordion
                elevation={0}
                style={{
                  border: '#00B8D9 solid 1px',
                  borderRadius: '7px',
                  padding: 0,
                }}
              >
                <AccordionSummary
                  style={{ color: '#00B8D9' }}
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <ErrorIcon style={{ marginRight: '1rem' }} />
                  <Typography
                    style={{ color: '#006C9C' }}
                  >
                    Segunda Aprovação
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>

            <Grid item xs={12} mb={1}>
              <Typography variant="h3" style={{ fontSize: '1.4rem' }}>
                Em espera
              </Typography>
            </Grid>

            <Grid item xs={12} mb={4}>
              <Accordion
                elevation={0}
                style={{
                  border: '#00B8D9 solid 1px',
                  borderRadius: '7px',
                  padding: 0,
                }}
              >
                <AccordionSummary
                  style={{ color: '#00B8D9' }}
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <ErrorIcon style={{ marginRight: '1rem' }} />
                  <Typography
                    style={{ color: '#006C9C' }}
                  >
                    Instalação do Certificado
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>

            <Grid item xs={12} mb={1}>
              <Typography variant="h3" style={{ fontSize: '1.4rem' }}>
                Concluidos
              </Typography>
            </Grid>

            <Grid item xs={12} mb={1}>
              <Accordion
                elevation={0}
                style={{
                  border: '#36B37E solid 1px',
                  borderRadius: '7px',
                  padding: 0,
                }}
              >
                <AccordionSummary
                  style={{ color: '#36B37E' }}
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <CheckIcon style={{marginRight: '1rem'}}/>
                  <Typography
                    style={{ color: '#1B806A' }}
                  >
                    Segunda Aprovação
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>
            <Grid item xs={12} mb={4}>
              <Accordion
                elevation={0}
                style={{
                  border: '#36B37E solid 1px',
                  borderRadius: '7px',
                  padding: 0,
                }}
              >
                <AccordionSummary
                  style={{ color: '#36B37E' }}
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <CheckIcon style={{marginRight: '1rem'}}/>
                  <Typography
                    style={{ color: '#1B806A' }}
                  >
                    Validação de Controle de Domínio
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </>
  );
}
