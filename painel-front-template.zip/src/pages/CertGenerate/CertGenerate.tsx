import { Helmet } from 'react-helmet-async';
import { Container, Typography, Paper, Divider, Box } from '@mui/material';
import { useSettingsContext } from '../../components/settings';
import DesktopStepper from '../../components/DesktopStepper';
import { useMemo } from 'react';
import CertChoice from './components/CertChoice';
import CertCSR from './components/CertCSR';
import CertContact from './components/CertContact';
import CertOrganization from './components/CertOrganization';
import CertConfirmation from './components/CertConfirmation';

export default function CertGenerate() {
  const { themeStretch } = useSettingsContext();

  const onFinish = () => {
    console.log("finish")
  }

  const onClose = () => {
    console.log("closed")
  }

  const stepElements = useMemo(() => {
    return [
      {
        label: 'Escolha dos Certificados',
        element: <CertChoice />,
        canProceed: true
      },
      {
        label: 'CSR',
        element: <CertCSR />,
        canProceed: true
      },
      {
        label: 'Dados de Contato',
        element: <CertContact />,
        canProceed: true
      },
      {
        label: 'Dados da Empresa',
        element: <CertOrganization />,
        canProceed: true
      },
      {
        label: 'Confirmação dos Dados',
        element: <CertConfirmation />,
        canProceed: true
      },
    ]
  }, []);


  return (
    <>
      <Helmet>
        <title>Emitir Certificado</title>
      </Helmet>

      <Container maxWidth={themeStretch && false}>
        <Paper elevation={3} style={{ padding: '2rem', marginTop: '2rem', height: '100%'}} >
          <Typography variant="h3" paragraph>
            Emitir Certificado
          </Typography>

          <Divider />
          <Box style={{marginBottom: '4rem'}}>
            <DesktopStepper
              canProceed
              onDismiss={onClose}
              onFinish={onFinish}
              steps={stepElements}
              buttonNextLabel="Avançar"
              buttonSubmitLabel="Finalizar"
            />
          </Box>
        </Paper>
      </Container>
    </>
  );
}
