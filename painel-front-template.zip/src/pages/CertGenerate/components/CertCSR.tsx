import { Box, Grid } from '@mui/material';
import CustomTextField from '../../../components/CustomTextField';
import { useNewEmissionContext } from '../../../context/certEmissionContext';
import { decodeCSRAPI } from '../../../services/sectigo.services';
import { useState } from 'react';

const CertCSR = () => {
  const [inputError, setInputError ] = useState(false);

  const { 
    addCsr,
    csr,
    addCsrError,
    addCsrLoading,
    csrError,
    csrLoading,
  } = useNewEmissionContext();

  const getCsr = async (csr: string) => {
    addCsrLoading?.(true);
    try {
      const cleanChar = encodeURIComponent(csr);
      const { data } = await decodeCSRAPI(`csr=${cleanChar}`);
      const parsed = data.csrData.split('\n')[0]

      addCsr?.(cleanChar);

      if(+parsed){
        addCsrError?.(true);
        setInputError(true)
      } else {
        console.log("ERROR")
        setInputError(false)
        addCsrError?.(false);
      }
    } catch (err) {
      console.log('error', err);
    } finally {
      addCsrLoading?.(false);
    }
  };

  return (
    <Box style={{ margin: '0', padding: '0', marginTop: '2rem' }}>
      <Grid container spacing={2} style={{ marginTop: '2rem' }}>
        <Grid item md={12}>
          <CustomTextField
            label="Digite a solicitação de assinatura do Certificado"
            rows={10}
            fullWidth
            multiline
            name="csr"
            type="standard"
            value={csr}
            placeholder="Digite a solicitação de assinatura do Certificado"
            onChange={(e) => getCsr(e.target.value)}
            error={inputError}
            helperText={inputError && 'CSR Inválido'}
          />
        </Grid>
      </Grid>
    </Box>
  );
};
export default CertCSR;
