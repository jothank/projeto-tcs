import {
  Box,
  FormControl,
  Grid,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  Skeleton,
} from '@mui/material';
import CustomTextField from '../../../components/CustomTextField';
import { useEffect, useState } from 'react';
import DateRangeIcon from '@mui/icons-material/DateRange';
import SearchIcon from '@mui/icons-material/Search';
import DateRangePicker from '../../../components/date-range-picker';
import MUIDataTable from 'mui-datatables';
import { getClientAPI, getOrdersAPI, getProductsAPI } from '../../../services/whmcs.services';
import { formatCurrency } from '../../../utils/formats';
import { fDate } from '../../../utils/formatTime';
import { ProductsDTO } from '../../../@types/DTO/productsDTO';
import { useNewEmissionContext } from '../../../context/certEmissionContext';

export const columns = [
  {
    name: 'nomeCert',
    label: 'Tipo de Certificado',
    options: {
      filterType: 'none',
    },
  },
  {
    name: 'regData',
    label: 'Data de Solicitação',
    option: {
      sort: false,
      filter: false,
    },
  },
  {
    name: 'untilData',
    label: 'Data de Expiração',
    option: {
      sort: false,
      filter: false,
    },
  },
  {
    name: 'regNextData',
    label: 'Próximo Vencimento',
  },
  {
    name: 'price',
    label: 'Preço',
  },
  {
    name: 'quantity',
    label: 'Progresso',
  },
];

const CertChoice = () => {
  const [openDataRange, setOpenDataRange] = useState(false);
  const [dataInicial, setDataInicial] = useState<any>(new Date());
  const [dataFinal, setDataFinal] = useState<any>(new Date());
  const [dataType, setDataType] = useState('');
  const [searchData, setSearchData] = useState('');
  const [products, setProducts] = useState<ProductsDTO[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const { addProducts } = useNewEmissionContext();

  useEffect(() => {
    getClientId();
  }, []);

  const getClientId = async () => {
    setLoadingProducts(true)
    try {
      const { data: client } = await getClientAPI('sandreia@marinha.mil.br');
      if (client.data.totalresults === 1) {
        await getProducts(client.data.clients.client[0].id);
      }
    } catch (err) {
      console.log(err);
      setLoadingProducts(false)
    }
  };

  const period = {
    Free: 'Grátis',
    Annually: 'Anual',
    'One Time': 'Pagamento único',
    Biennially: 'Bienal',
    Triennially: 'Trienal',
    Monthly: 'Mensal',
    Quarterly: 'Quadrimestral',
    'Semi-Annually': 'Semi-anual',
  };

  const getPeriodPort = (value: keyof typeof period) => {
    return period[value];
  };

  const getProducts = async (id: number) => {
    try {
      const { data } = await getProductsAPI(83);      
      const dataSet = data.products.product.filter((item: any) => item.domain === '').map((item: any) => {
          return {
            _id: item.id,
            nomeCert: item.name,
            regData: fDate(item.regdate),
            untilData: fDate(item.nextduedate),
            regNextData: fDate(item.nextduedate),
            circleByling: getPeriodPort(item.billingcycle),
            price: `${formatCurrency(item.firstpaymentamount)} ${getPeriodPort(item.billingcycle)}`,
            quantity: '9/10',
          };
      });

      console.log('Dataset', dataSet);

      setProducts(dataSet);
    } catch (err) {
      console.log(err);
    } finally{
      setLoadingProducts(false)
    }
  };

  const options = {   
    selectableRowsHeader: true,
    filterType: 'checkbox',
    fixedHeader: true,
    download:false,
    selectableRows: "multiple",
    search: false,
    filter: false,
    responsive: 'standard',
    print: false,
    viewColumns: false,
    enableNestedDataAccess: '.',
    onRowSelectionChange: (currentRowsSelected: any, allRowsSelected: any) => {
      const allrows = allRowsSelected.map((item: any, index: number) => products[index]);
      addProducts?.(allrows);
    },
    elevation: 0,
    rowsPerPage: 10,
    rowsPerPageOptions: [10, 30, 100],
    textLabels: {
      body: {
        noMatch: 'Desculpe, nenhum certificado foi encontrado',
        toolTip: 'Organizar',
        columnHeaderTooltip: (column: { label: any }) => `Organizar por ${column.label}`,
      },
      pagination: {
        next: 'Próxima Página',
        previous: 'Voltar Página',
        rowsPerPage: 'Certificados por Página:',
        displayRows: 'de',
      },
      toolbar: {
        search: 'Buscar',
        downloadCsv: 'Download CSV',
        print: 'Imprimir',
        viewColumns: 'Ver Colunas',
        filterTable: 'Filtrar Tabela',
      },
      filter: {
        all: 'TODOS',
        title: 'FILTROS',
        reset: 'LIMPAR',
      },
      viewColumns: {
        title: 'Mostrar Colunas',
        titleAria: 'Mostrar/Esconder Colunas',
      },
      selectedRows: {
        text: 'Certificado(s) selecionado',
      },
    },
  };

  return (
    <Box style={{ margin: '0', padding: '0', marginTop: '2rem' }}>
      <Grid container spacing={2} style={{ marginTop: '2rem' }}>
        <Grid item md={4}>
          <DateRangePicker
            onChangeStartDate={(e) => setDataInicial(e)}
            onChangeEndDate={(e) => setDataFinal(e)}
            open={openDataRange}
            onClose={() => setOpenDataRange(false)}
            startDate={dataInicial}
            endDate={dataFinal}
          />

          <FormControl fullWidth>
            <InputLabel style={{ color: '#878787' }}>Data</InputLabel>
            <Select
              label="Data"
              value={dataType}
              placeholder="Escolha uma data"
              startAdornment={<DateRangeIcon style={{ color: '#878787', marginRight: '1rem' }} />}
              onChange={(e) => {
                setOpenDataRange(true);
                setDataType(e.target.value);
              }}
            >
              <MenuItem value="Solicitação">Solicitação</MenuItem>
              <MenuItem value="Expiração">Expiração</MenuItem>
              <MenuItem value="Próximo Vencimento">Próximo Vencimento</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item md={8}>
          <CustomTextField
            fullWidth
            name="searchData"
            type="standard"
            value={searchData}
            placeholder="Pesquisa por Tipo de Certificado"
            onChange={(e) => setSearchData(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon style={{ color: '#878787', marginRight: '1rem' }} />
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item md={12} style={{ marginTop: '2rem' }}>
        {loadingProducts ?
            Array(10).fill('').map(
              (item: any, index: number) => {
                return (
                  <Skeleton key={index} variant="rectangular" height={30} style={{ marginTop: '1rem' }} />);
              },
            )
            :
          <MUIDataTable
            title=""
            data={products as any}
            columns={columns as any}
            options={options as any}
          /> 
            }
        </Grid>
      </Grid>
    </Box>
  );
};
export default CertChoice;
