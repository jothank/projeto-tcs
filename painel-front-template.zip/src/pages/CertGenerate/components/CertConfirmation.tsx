import { Box, Grid, Typography } from '@mui/material';


const CertConfirmation = () => {

  return (
    <Box style={{ margin: '0', padding: '0', marginTop: '2rem' }} >
      <Grid container spacing={2} justifyContent='space-evenly' alignContent='space-between' style={{ marginTop: '2rem' }}>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Nome Comum (CN)
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Waldemar Henrique G. Mattos Jr
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Primeiro Nome
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Junior
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Endereço da Organização
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            R. 7 Norte, apt 303, CEP 11070-370
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Organização (0)
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            DW Consultoria
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Último Nome
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Junior
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Segundo Endereço
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Não possuí
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Unidade Organizacional (OU)
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Não possuí
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Cidade
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Brasília
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Cidade
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Brasília
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Cidade
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Brasília
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Estado
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Distrito Federal
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Estado
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Distrito Federal
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            Localidade
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Distrito Federal
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            CEP
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            11070-370
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            CEP
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            11070-370
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            País
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Brasil
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            País
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Brasil
          </Typography>
        </Grid>

        <Grid item md={4} xs={12}>
          <Typography variant="subtitle1" paragraph style={{ color: '#637381', fontSize: '12px' }}>
            País
          </Typography>
          <Typography variant="subtitle1" paragraph style={{ color: '#000000', fontSize: '14px' }}>
            Brasil
          </Typography>
        </Grid>
      </Grid>
    </Box >
  );
};
export default CertConfirmation;
