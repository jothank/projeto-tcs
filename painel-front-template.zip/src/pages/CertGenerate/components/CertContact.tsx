import { Box, Grid, Alert, Button, InputAdornment, CircularProgress, FormHelperText } from '@mui/material';
import CustomTextField from '../../../components/CustomTextField';
import { useCallback, useState } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import { useNewEmissionContext } from '../../../context/certEmissionContext';
import { checkCPF } from '../../../services/serpro.services';
import { clearChar } from '../../../utils/formats';
import CheckIcon from '@mui/icons-material/Check';
import ErrorIcon from '@mui/icons-material/ErrorOutline';

const CertContact = () => {
  const [doc, setDoc] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');

  const [docChecked, setDocChecked] = useState<boolean | null>(null);

  const {
    addInfoClient,
    addInfoClientError,
    addInfoClientLoading,
    infoClient,
    infoClientError,
    infoClientLoading,
  } = useNewEmissionContext();

  const getCheckDoc = async () => {
    let cleanDoc = clearChar(doc);
    addInfoClientLoading?.(true);

    console.log('cleanDoc lenght', cleanDoc?.length);
    console.log('cleanDoc', cleanDoc);

    if (cleanDoc && cleanDoc.length === 11) {
      checkCPF(cleanDoc!)
        .then((res) => {
          addInfoClientError?.(false);
          console.log('cpf', res.data);
          const fullName = res.data.nome.split(' ');
          const firstName = fullName[0];
          const lastName = fullName[fullName.length - 1]
          
          console.log('full Name', fullName)
          console.log('first name', firstName)
          console.log('last Name', lastName )

          addInfoClient?.({ ...infoClient!, cpf: cleanDoc!, firstName, lastName})
          addInfoClientError?.(false);
          setDocChecked(true);
        })
        .catch((err) => {
          console.log(err);
          addInfoClientError?.(true);
          setDocChecked(false);
        })
        .finally(() => {
          addInfoClientLoading?.(false);
        });
    } else {
      addInfoClientError?.(true);
      setDocChecked(false);
      addInfoClientLoading?.(false);
    }
  }

  return (
    <Box style={{ margin: '0', padding: '0', marginTop: '2rem' }}>
      <Grid container spacing={2} style={{ marginTop: '2rem' }}>
        <Grid item md={12}>
          <Alert
            variant="filled"
            style={{ background: '#CAFDF5', color: '#003768' }}
            severity="info"
          >
            Utilizaremos esses dados de contato caso surjam incertezas ou dificuldades durante o
            processo de validação.
          </Alert>
        </Grid>

        <Grid item md={10} xs={12}>
          <CustomTextField
            label="Pesquisar por CPF"
            fullWidth
            name="cpf"
            type="cpf"
            value={doc}
            placeholder="Digite um CPF válido"
            onChange={(e) => setDoc(e.target.value)}
            error={infoClientError}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  {infoClientLoading ? (
                    <CircularProgress
                    size={15}
                      style={{ margin: '10px', color: '#dfdfdf' }}
                    />
                  ) : docChecked  ? (
                    <CheckIcon style={{ color: '#449364' }} />
                  ) : (
                    docChecked !== null && <ErrorIcon style={{ color: 'red' }} />
                  ) 
                  }
                </InputAdornment>
              ),
            }}
          />
          <FormHelperText style={{ color: 'red', fontSize: '14px' }}>
            {infoClientError && 'Por favor, digite um CPF válido.'}
          </FormHelperText>
        </Grid>

        <Grid item md={2} xs={12}>
          <Button
            fullWidth
            style={{ height: '55px', background: '#001d36' }}
            variant="contained"
            color="primary"
            onClick={getCheckDoc}
            startIcon={<SearchIcon />}
          >
            Pesquisar
          </Button>
        </Grid>

        <Grid item md={6} xs={12}>
          <CustomTextField
            label="Primeiro Nome"
            fullWidth
            name="firstName"
            type="standard"
            value={infoClient?.firstName}
            placeholder="Digite seu Primeiro Nome"
            onChange={(e) => addInfoClient?.({ ...infoClient!, firstName : e.target.value})}
          />
        </Grid>

        <Grid item md={6} xs={12}>
          <CustomTextField
            label="Último Nome"
            fullWidth
            name="lastName"
            type="standard"
            value={infoClient?.lastName}
            placeholder="Digite seu Último Nome"
            onChange={(e) => addInfoClient?.({ ...infoClient!, lastName : e.target.value})}
          />
        </Grid>

        <Grid item md={12} xs={12}>
          <CustomTextField
            label="Endereço de E-mail"
            fullWidth
            name="email"
            type="standard"
            value={email}
            placeholder="Digite seu E-mail"
            onChange={(e) => setEmail(e.target.value)}
          />
        </Grid>

        <Grid item md={12} xs={12}>
          <CustomTextField
            label="Cargo/Função"
            fullWidth
            name="role"
            type="standard"
            value={role}
            placeholder="Digite seu Cargo/Função"
            onChange={(e) => setRole(e.target.value)}
          />
        </Grid>
      </Grid>
    </Box>
  );
};
export default CertContact;
