import { Box, Grid, Alert, Button } from '@mui/material';
import CustomTextField from '../../../components/CustomTextField';
import { useState } from 'react';
import SearchIcon from '@mui/icons-material/Search';

const CertOrganization = () => {
  const [cnpj, setCnpj] = useState('')
  const [orgAddress, setOrgAddress] = useState('')
  const [orgAddressSecond, setOrgAddressSecond] = useState('')
  const [city, setCity] = useState('')
  const [state, setState] = useState('')
  const [cep, setCep] = useState('')

  return (
    <Box style={{ margin: '0', padding: '0', marginTop: '2rem' }} >
      <Grid container spacing={2} style={{ marginTop: '2rem' }}>
      
        <Grid item md={10} xs={12}>
          <CustomTextField
            label='Pesquisar por CNPJ'
            fullWidth
            name="cnpj"
            type="cpfCnpj"
            value={cnpj}
            placeholder='Digite um CNPJ válido'
            onChange={(e) => setCnpj(e.target.value)}
          />
        </Grid>

        <Grid item md={2} xs={12}>
          <Button 
          fullWidth 
          style={{height: '55px', background: '#001d36'}} 
          variant="contained" 
          color="primary" 
          startIcon={<SearchIcon/>}>
            Pesquisar
          </Button>
        </Grid>

        <Grid item md={12} xs={12}>
          <CustomTextField
            label='Endereço da Organização'
            fullWidth
            name="orgAddress"
            type="standard"
            value={orgAddress}
            placeholder='Digite o endereço da sua empresa'
            onChange={(e) => setOrgAddress(e.target.value)}
          />
        </Grid>

        <Grid item md={12} xs={12}>
          <CustomTextField
            label='Segundo Endereço'
            fullWidth
            name="orgAddressSecond"
            type="standard"
            value={orgAddressSecond}
            placeholder='Digite o segundo endereço(caso houver) da sua Empresa '
            onChange={(e) => setOrgAddressSecond(e.target.value)}
          />
        </Grid>

        <Grid item md={6} xs={12}>
          <CustomTextField
            label='Cidade'
            fullWidth
            name="city"
            type="standard"
            value={city}
            placeholder='Digite o nome da sua Cidade'
            onChange={(e) => setCity(e.target.value)}
          />
        </Grid>

        <Grid item md={6} xs={12}>
          <CustomTextField
            label='Estado'
            fullWidth
            name="state"
            type="standard"
            value={state}
            placeholder='Digite seu Estado'
            onChange={(e) => setState(e.target.value)}
          />
        </Grid>

        <Grid item md={12} xs={12}>
          <CustomTextField
            label='CEP'
            fullWidth
            name="cep"
            type="standard"
            value={cep}
            placeholder='Digite seu CEP'
            onChange={(e) => setCep(e.target.value)}
          />
        </Grid>
      </Grid>
    </Box >
  );
};
export default CertOrganization;
