import { Helmet } from 'react-helmet-async';
import { useSettingsContext } from '../components/settings';
import MUIDataTable from "mui-datatables";
import { useCallback, useEffect, useState } from 'react';
import FileDownload from '@mui/icons-material/Description';
import FileViewerDialog, { DigitalDocumentDTO } from '../components/FileViewerDialog/FileViewerDialog';
import { Chip, IconButton, Container, Paper, Typography, Tooltip, Skeleton } from '@mui/material';
import { useFeedback } from '../context/Feedback';
import { useNavigate } from 'react-router';
import { listAllOrdersAPI } from '../services/orders.services';
import { getAllOrdersDTO } from '../@types/DTO/ordersDTO';


interface certListDTO {
  _id: string,
  cliente: string,
  pedido: number,
  data: string,
  paymentMethod: string,
  paymentStatus: string,
  approved?: boolean,
  total?: string,
}



export const mockCertificates = [
  {
    _id: "643d936a3c395b681d161d09",
    cliente: "Companhia de Tecnologia da Informação do Estado de Minas Gerais PRODEMGE",
    pedido: 5887903,
    data: "25/04/2023",
    paymentMethod: "Transferência Bancária",
    paymentStatus: "Fatura em análise",
    approved: true,
    total: 'R$7.170,00',
  },
  {
    _id: "643d936a3c395b681d161d10",
    cliente: "CONSELHO REGIONAL DE ADMINISTRAÇÃO DE MINAS GERAIS MG",
    pedido: 1565534,
    data: "20/04/2023",
    paymentMethod: "Transferência Bancária",
    paymentStatus: "Fatura em Deletada",
    approved: true,
    total: 'R$89,00',
  },
  {
    _id: "643d936a3c395b681d161d11",
    cliente: "Tribunal Regional do Trabalho da 19ª Região",
    pedido: 6465455,
    data: "19/04/2023",
    paymentMethod: "Transferência Bancária",
    paymentStatus: "Incompleto",
    approved: true,
    total: 'R$1.902,00',
  },
  {
    _id: "643d936a3c395b681d161d12",
    cliente: "CONSELHO FEDERAL DE MEDICINA VETERINÁRIA",
    pedido: 5565582,
    data: "04/04/2023",
    paymentMethod: "Transferência Bancária",
    paymentStatus: "Completo",
    approved: true,
    total: 'R$402,00',
  },

]


export default function CertManager() {
 
  const navigateTo = useNavigate();
  
  const columns = [
    {
      name: "idXDB",
      label: "Pedido",
      options: {
        filterType: 'textField'
      }
    },
    {
      name: "user.name",
      label: "Cliente",
    },
    {
      name: "dataEmission",
      label: "Data",
      type: "date",
    },
    {
      name: "paymentMethod",
      label: "Tipo de Pagamento",
    },
    {
      name: "totalPrice",
      label: "Total",
      options: {
        filterType: 'textField'
      }
    },
    {
      name: "status",
      label: "Status do Pagamento",
      options: {
        filter: false,
        customBodyRender: (_value: any, tableMeta: any, _updateValue: any) => {
          return (
            selectionChips(_value)
          );
        },
      },
    },
    {
      name: "idXDB",
      label: " ",
      options: {
        sort: false,
        filter: false,
        customBodyRender: (_value: any, tableMeta: any, _updateValue: any) => {
          return (
            <Tooltip title="Visualizar Certificado">
              <IconButton size="large" onClick={() => sendToCert(_value)}>
                <FileDownload/>
              </IconButton>
            </Tooltip>
          );
        },
      },
    },
  ]
  const sendToCert = (idCert : number) => {
    navigateTo(`/home/certificados/gerenciar-certificados/${idCert}`);
  }

  const selectionChips = useCallback((value: string) => {
    let label;
    let color;

    switch (value) {
      case 'Completo':
        label = 'Completo'
        color = 'success'
        break;
      case 'Incompleto':
        label = 'Incompleto'
        color = 'error'
        break;
      case 'Fatura em Deletada':
        label = 'Fatura em Deletada'
        color = 'error'
        break;
      case 'Fatura em análise':
        label = 'Fatura em análise'
        color = 'warning'
        break;
    
      default:
        label = 'Em analise'
        color = 'default'
    }

    return (
      <Chip
        color={color as any}
        label={label}
        style={{width: '10rem'}}
      />
    )
  },[])

  const options = {
    onRowSelectionChange: (currentRowsSelected: any, allRowsSelected: any) => {
      console.log('teste1', currentRowsSelected, allRowsSelected);
      console.log('teste', dataUser[currentRowsSelected[0]?.dataIndex!]);
    },
    selectableRowsHeader: true,
    fixedHeader: true,
    selectableRows: 'none',
    download: true,
    filter: true,
    responsive: 'standard',
    print: true,
    viewColumns: false,
    enableNestedDataAccess: '.',
    elevation: 0,
    rowsPerPage: 30,
    rowsPerPageOptions: [30, 60, 100],
    textLabels: {
      body: {
        noMatch: "Desculpe, nenhum certificado foi encontrado",
        toolTip: "Organizar",
        columnHeaderTooltip: (column: { label: any; }) => `Organizar por ${column.label}`
      },
      pagination: {
        next: "Próxima Página",
        previous: "Voltar Página",
        rowsPerPage: "Linhas por Página:",
        displayRows: "de",
      },
      toolbar: {
        search: "Buscar",
        downloadCsv: "Download CSV",
        print: "Imprimir",
        viewColumns: "Ver Colunas",
        filterTable: "Filtrar Tabela",
      },
      filter: {
        all: "TODOS",
        title: "FILTROS",
        reset: "LIMPAR",
      },
      viewColumns: {
        title: "Mostrar Colunas",
        titleAria: "Mostrar/Esconder Colunas",
      },
      selectedRows: {
        text: "Certificado(s) selecionados",
        delete: "Apagar",
        deleteAria: "Apagar Linhas Selecionadas",
      },
    }
  };

  const { themeStretch } = useSettingsContext();
  const [openFileViewerDialog, setOpenFileViewerDialog] = useState(false);
  const [dataUser, setDataUser] = useState<certListDTO[]>(mockCertificates)

  const [orderList, setOrdersList] = useState<getAllOrdersDTO[]>()

  const [fileToView, setFileToView] = useState<DigitalDocumentDTO>();
  const { addFeedback } = useFeedback();
  const [loadingCerts, setLoadingCerts] = useState(false);

  useEffect(()=> {
    getAllOrders()
  },[])

  const getAllOrders = () => {
   
    listAllOrdersAPI().then(res => {
      console.log("DataSet Orders", res.data)
      setOrdersList(res.data);

    }).catch(err => {
      console.log("error", err)
    })
  }

  return (
    <>
      <Helmet>
        <title>Gerenciamento de Certificados</title>
      </Helmet>

      {fileToView &&
        <FileViewerDialog
          open={openFileViewerDialog}
          title={fileToView?.nome}
          handleClose={() => setOpenFileViewerDialog(false)}
          document={fileToView}
        />
      }
      <Container maxWidth={themeStretch && false}>
        <Paper elevation={3} style={{ padding: '2rem', marginTop: '2rem' }} >
          <Typography variant="h3" paragraph>
            Gerenciamento de Certificados
          </Typography>
          {loadingCerts ?
            Array(13).fill('').map(
              (item: any, index: number) => {
                return (
                  <Skeleton key={index} variant="rectangular" height={30} style={{ marginTop: '1rem' }} />);
              },
            )
            :
            <MUIDataTable
              title=''
              data={orderList as any}
              columns={columns as any}
              options={options as any}
            />
          }
        </Paper>
      </Container>
    </>
  );
}


