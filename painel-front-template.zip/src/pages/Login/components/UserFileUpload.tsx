import { DialogContent, FormHelperText, Typography } from '@mui/material';
import React from 'react';

import { FilePicker } from '../../../components/FilePicker';
import '../styles.css'
import { useNewUserContext } from '../../../context/newUserContext';
import { convertBase64 } from '../../../utils/files';

const UserFileUpload: React.FC = () => {

  const {
    fileErrors,
    addNewUserFile,
    addFileErrors,
  } = useNewUserContext()

  const handleSendFile = async (file: any) => {
    
    if (file.length > 0) {
      const { name, type } = file[0];
      
      addFileErrors('');
    
      let dataSet = {
        name,
        type,
        base64: await convertBase64(file[0])
      }
      addNewUserFile(dataSet);
      
    } else {
      addFileErrors('*Por favor, insira um arquivo.');
    }
  }

  const handleDeletFile = () => {
    let dataSet = {
      name : '',
      type :'',
      base64: ''
    }
    addNewUserFile(dataSet);
    addFileErrors('*Por favor, insira um arquivo.');
  }

  return (
    <DialogContent style={{ padding: '0', marginBottom: '2rem', overflow: 'initial' }}>
      <Typography
        variant="subtitle1"
        style={{ margin: '2rem 0 1rem', color: '#323232', fontWeight: '600' }}
      >
        Adicione seu <strong>contrato social</strong>:
      </Typography>
      <FilePicker
        fieldName="comprovantes"
        filesLimit={1}
        acceptedFiles={[
          'application/pdf',
          'image/jpeg',
          'image/jpg',
          'image/png',
        ]}
        onChange={handleSendFile}
        onDelete={handleDeletFile}
        maxFileSize={10000000}
        dropzoneText="Anexe seu Contrato Social (PDF, JPG, PNG de até 10MB)"
      />
    
    </DialogContent >
  );
};
export default UserFileUpload;
