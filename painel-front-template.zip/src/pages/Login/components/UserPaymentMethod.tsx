import {
  DialogContent,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Typography,
} from '@mui/material';

import React from 'react';
import { useNewUser } from '../../../hooks/useNewUser';
import { useNewUserContext } from '../../../context/newUserContext';

const UserPaymentMethod: React.FC = () => {

  const {
    paymentMethod,
    addPaymentMethod
  } = useNewUserContext()

  return (
    <DialogContent style={{padding: 0}}>
      <Typography
        variant="subtitle1"
        style={{ margin: '2rem 0 1rem', color: '#323232', fontWeight: '600' }}
      >
        Preencha os dados abaixo:
      </Typography>
      <FormControl fullWidth variant="outlined" style={{ marginTop: '1rem' }}>
        <InputLabel>Método de Pagamento</InputLabel>
        <Select
          name="metodoPagamento"
          label="Método de Pagamento"
          value={paymentMethod}
          onChange={e => addPaymentMethod(e.target.value)}
        >
          <MenuItem value="prePago">Pré Pago</MenuItem>
          <MenuItem value="posPago">Pós Pago</MenuItem>
        </Select>
      </FormControl>
    </DialogContent>
  );
};
export default UserPaymentMethod;
