import { Helmet } from 'react-helmet-async';
import { useSettingsContext } from '../components/settings';
import MUIDataTable from "mui-datatables";
import { useCallback, useEffect, useState } from 'react';
import { listNewUserAPI } from '../services/users.services';
import FileDownload from '@mui/icons-material/Description';
import { setCpfCnpjMask } from '../utils/masks';
import FileViewerDialog, { DigitalDocumentDTO } from '../components/FileViewerDialog/FileViewerDialog';
import { Chip, IconButton, Container, Paper, Typography, Tooltip, Skeleton, Divider } from '@mui/material';
import { useFeedback } from '../context/Feedback';
import { useNavigate } from 'react-router';
import { CustomDialog } from '../components/CustomDialog';


interface logListDTO {
  _id: string,
  usuario: string,
  acao?: string,
  certificados?: string,
  ticketInternos?: string,
  ticketsExternos?: string,
  data: string,
  detalhes?: string,
  role: string,

}

export const mockLogs = [
  {
    _id: "643d936a3c395b681d161d19",
    usuario: "XDB",
    acao: 'Geração de Certificado OV',
    certificados: "Certificado OV",
    data: "25/04/2023 - 9:40",
    detalhes: 'Criado OV de número 2364',
    role: 'Admins',
  },
  {
    _id: "643d936a3c395b681d161d29",
    usuario: "XDB",
    acao: "Usuário Logou na conta",
    data: "25/04/2023 - 9:40",
    role:'Admins',
  },
  {
    _id: "643d936a3c395b681d161d39",
    usuario: "XDB",
    acao: "Usuário deslogou da conta",
    data: "25/04/2023 - 12:40",
    role: 'Admins',
  },
  {
    _id: "643d936a3c395b681d161449",
    usuario: "XDB",
    acao: "Usuário Cancelou Certificado EV",
    data: "26/04/2023 - 14:40",
    role: 'Admins',
  },
  {
    _id: "643d936a3c395b681d161229",
    usuario: "XDB",
    acao: 'Geração de Certificado EV',
    certificados: "Certificado EV",
    data: "22/04/2023 - 9:40",
    role: 'Super Admin',
  },
  {
    _id: "643d936a3c395b681d111109",
    usuario: "XDB",
    acao: "Usuário atualizou seu cadastro",
    data: "30/04/2023 - 15:30",
    role: 'Revenda',
  },
  {
    _id: "643d936a3c395b681d161239",
    usuario: "XDB",
    acao: "Usuário abriu um ticket de número 1232153",
    ticketInternos: '1232153',
    data: "20/04/2023 - 19:00",
    role: 'Usuário',
  },
]

export default function UserLogs() {

  const columns = [
    {
      name: "data",
      label: "Data",
      options: {
        filterType: 'textField'
      }
    },
    {
      name: "usuario",
      label: "Usuário",
      option: {
        sort: false,
        filter: false,
      }
    },
    {
      name: "acao",
      label: "Atividade",
      option: {
        sort: false,
        filter: false,
      }
    },
    {
      name: "role",
      label: "Perfil",
    },
    {
      name: "certificados",
      label: "Certificado",
    },
    {
      name: "ticketInternos",
      label: "Tickets Internos",
    },
    {
      name: "ticketExternos",
      label: "Tickets Externos",
      option: {
        sort: false,
        filter: false,
      }
    },
    // {
    //   name: "_id",
    //   label: " ",
    //   options: {
    //     sort: false,
    //     filter: false,
    //     customBodyRender: (_value: any, tableMeta: any, _updateValue: any) => {
    //       return (
    //         <Tooltip title="Visualizar Logs">
    //           <IconButton size="large" onClick={() => openLogDetails(_value)}>
    //             <FileDownload />
    //           </IconButton>
    //         </Tooltip>
    //       );
    //     },
    //   },
    // },
  ]

  const openLogDetails = (idLog: number) => {
    const data = mockLogs.find((item: any) => item._id === idLog);
    setSelectLog(data as any);
    console.log("DataLogs", data)
    setOpenDialog(true);
  }


  const options = {
    selectableRowsHeader: true,
    fixedHeader: true,
    selectableRows: 'none',
    download: true,
    filter: true,
    responsive: 'standard',
    print: true,
    viewColumns: false,
    enableNestedDataAccess: '.',
    elevation: 0,
    rowsPerPage: 30,
    rowsPerPageOptions: [30, 60, 100],
    textLabels: {
      body: {
        noMatch: "Desculpe, nenhum registro foi encontrado",
        toolTip: "Organizar",
        columnHeaderTooltip: (column: { label: any; }) => `Organizar por ${column.label}`
      },
      pagination: {
        next: "Próxima Página",
        previous: "Voltar Página",
        rowsPerPage: "Linhas por Página:",
        displayRows: "de",
      },
      toolbar: {
        search: "Buscar",
        downloadCsv: "Download CSV",
        print: "Imprimir",
        viewColumns: "Ver Colunas",
        filterTable: "Filtrar Tabela",
      },
      filter: {
        all: "TODOS",
        title: "FILTROS",
        reset: "LIMPAR",
      },
      viewColumns: {
        title: "Mostrar Colunas",
        titleAria: "Mostrar/Esconder Colunas",
      },
      selectedRows: {
        text: "Log(s) selecionados",
        delete: "Apagar",
        deleteAria: "Apagar Linhas Selecionadas",
      },
    }
  };

  const { themeStretch } = useSettingsContext();
  const [openFileViewerDialog, setOpenFileViewerDialog] = useState(false);
  const [dataUser, setDataUser] = useState<any[]>(mockLogs)
  const [fileToView, setFileToView] = useState<DigitalDocumentDTO>();
  const { addFeedback } = useFeedback();
  const [loadingCerts, setLoadingCerts] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectLog, setSelectLog] = useState();


  const getAllUsers = () => {
    console.log("listUSer")
    listNewUserAPI().then(res => {

      const dataSet = res.data.map((item: any) => ({
        name: item.name,
        doc: setCpfCnpjMask(item.doc),
        email: item.email,
        approved: item.approved,
        file: item.file[0],
        isOrg: item.isOrganization,
        id: item._id,
      }))

      // setDataUser(dataSet);

      console.log("DataSet", dataSet)

    }).catch(err => {
      console.log("error", err)
    })
  }

  return (
    <>
      <Helmet>
        <title>Log de Atividades</title>
      </Helmet>
      {openDialog &&
        <CustomDialog
          maxWidth="md"
          open={openDialog}
          handleClose={() => setOpenDialog(false)}
        >
          <Typography variant="body1" paragraph>
            {/* Id:{selectLog?._id}<br />
            Nome: {selectLog?.usuario}<br />
            Atividade:{selectLog?.acao}<br />
            Data: {selectLog?.data}<br />
            {selectLog?.detalhes && `Detalhes: ${selectLog?.detalhes}`} */}
          </Typography>
        </CustomDialog>
      }
      {fileToView &&
        <FileViewerDialog
          open={openFileViewerDialog}
          title={fileToView?.nome}
          handleClose={() => setOpenFileViewerDialog(false)}
          document={fileToView}
        />
      }

      <Container maxWidth={themeStretch && false}>
        <Paper elevation={3} style={{ padding: '2rem', marginTop: '2rem' }} >
          <Typography variant="h3" paragraph>
            Log de Atividades
          </Typography>
          <Divider />
          {loadingCerts ?
            Array(13).fill('').map(
              (item: any, index: number) => {
                return (
                  <Skeleton key={index} variant="rectangular" height={30} style={{ marginTop: '1rem' }} />);
              },
            )
            :
            <MUIDataTable
              title=''
              data={dataUser as logListDTO[]}
              columns={columns as any}
              options={options as any}
            />
          }
        </Paper>
      </Container>
    </>
  );
}


