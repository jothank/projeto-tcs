import axios, { CancelTokenSource } from 'axios';
import { getToken } from '../utils/isAuth';
import { useNavigate } from 'react-router';


//Api Sectigo
const apiSectigo = axios.create({
  baseURL: String(import.meta.env.VITE_HOST_XDB),
});

const isCancel = (error: Error) => axios.isCancel(error);

function getCancelTokenSource(): CancelTokenSource {
  return axios.CancelToken.source();
  
}

export { apiSectigo, isCancel, getCancelTokenSource };
