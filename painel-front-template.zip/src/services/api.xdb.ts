import axios, { CancelTokenSource } from 'axios';
import { getToken } from '../utils/isAuth';
import { useNavigate } from 'react-router';


//Api XDB server
const apiXDB = axios.create({
  baseURL: String(import.meta.env.VITE_HOST_XDB),
});



apiXDB.interceptors.request.use(
  
  async (req) => {
    const getToken = localStorage.getItem("accessToken");
    req.headers['Authorization'] = `Bearer ${getToken}`;
    return req;
  },
   (error) => {
    return Promise.reject(error);
  },
);

apiXDB.interceptors.response.use(
  function (response) {
    return response;
  },
  function (er) {
    if (axios.isAxiosError(er)) {
      if (er.response) {
        if (er.response.status == 401) {
          useNavigate()("/login");

        }
      }
    }

    return Promise.reject(er);
  }
);


const isCancel = (error: Error) => axios.isCancel(error);

function getCancelTokenSource(): CancelTokenSource {
  return axios.CancelToken.source();
  
}

export { apiXDB, isCancel, getCancelTokenSource };
