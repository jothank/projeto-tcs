import { AxiosResponse } from 'axios';
import { apiXDB } from './api.xdb';
import { getAllOrdersDTO } from '../@types/DTO/ordersDTO';


export const listAllOrdersAPI = async (): Promise<AxiosResponse<getAllOrdersDTO[]>> => {
  return await apiXDB.get('/orders');
};





