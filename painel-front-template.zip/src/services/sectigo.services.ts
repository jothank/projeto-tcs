import { AxiosResponse } from 'axios';
import { apiXDB } from './api.xdb';

export const decodeCSRAPI = async (
  csr : string
): Promise<AxiosResponse<any>> => {
  return await apiXDB.post('/sectigo/csr', 
  { csr: csr }
  );
};

