import { AxiosResponse } from 'axios';
import { apiXDB } from './api.xdb';


export const getOrdersAPI = async (
  userId: number
): Promise<AxiosResponse<any>> => {
  return await apiXDB.get(`/whmcs/orders/${userId}`);
};

export const getProductsAPI = async (
  userId: number
): Promise<AxiosResponse<any>> => {
  return await apiXDB.get(`/whmcs/products/${userId}`);
};

export const getClientAPI = async (
  email: string
): Promise<AxiosResponse<any>> => {
  return await apiXDB.get(`/whmcs/client`, {
    params: {
      email: email
    }
  }
  );
};





